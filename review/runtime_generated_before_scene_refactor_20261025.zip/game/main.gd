extends Control

const WorldScene = preload("res://world.gd")
var config: Dictionary
var world
var answer: RichTextLabel
var question: LineEdit
var status: Label
var state_label: Label
var metric_label: Label
var send_button: Button
var health_request: HTTPRequest
var client := HTTPClient.new()
var busy := false
var request_sent := false
var buffer := PackedByteArray()
var generated := ""
var started_usec := 0
var first_usec := 0
var request_state := {}
var request_prompt := ""
var log_dir := ""
var evidence_mode := false
var evidence_step := 0
var evidence_wait := 0.0
var request_count := 0
var failures := 0
var generation_frames := 0
var max_frame_ms := 0.0
var thinking_character_count := 0
var previous_frame_usec := 0

func _ready() -> void:
	config = JSON.parse_string(FileAccess.get_file_as_string("res://npc_config.json"))
	log_dir = ProjectSettings.globalize_path("res://../evidence").simplify_path()
	DirAccess.make_dir_recursive_absolute(log_dir)
	evidence_mode = "--demo-evidence" in OS.get_cmdline_user_args()
	var theme := Theme.new()
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Malgun Gothic", "맑은 고딕"])
	theme.default_font = font
	theme.default_font_size = 18
	self.theme = theme
	build_ui()
	health_request = HTTPRequest.new()
	health_request.timeout = 5
	add_child(health_request)
	health_request.request_completed.connect(check_ready)
	health_request.request("http://%s:%d/api/tags" % [config.host, int(config.port)])

func label(text_value: String, font_size := 18, color := Color("dae5f2")) -> Label:
	var result := Label.new()
	result.text = text_value
	result.add_theme_font_size_override("font_size", font_size)
	result.add_theme_color_override("font_color", color)
	return result

func button(text_value: String, action: Callable) -> Button:
	var result := Button.new()
	result.text = text_value
	result.custom_minimum_size.y = 42
	result.pressed.connect(action)
	return result

func build_ui() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for edge in ["left", "right", "top", "bottom"]: margin.add_theme_constant_override("margin_" + edge, 24)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	margin.add_child(root)
	root.add_child(label("로컬 AI NPC  /  상태 연동 시제품", 28, Color("f2f6ff")))
	root.add_child(label("게임의 현재 상태를 전달해 NPC가 답변합니다", 17, Color("92abc7")))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 24)
	root.add_child(row)
	world = WorldScene.new()
	world.interacted.connect(interact)
	row.add_child(world)
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(520, 530)
	right.add_theme_constant_override("separation", 12)
	row.add_child(right)
	right.add_child(label("정비사 하린", 26, Color("8ce1d6")))
	state_label = label("", 16, Color("f0d59a"))
	right.add_child(state_label)
	answer = RichTextLabel.new()
	answer.custom_minimum_size = Vector2(510, 280)
	answer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	answer.bbcode_enabled = false
	answer.add_theme_color_override("default_color", Color("e2ebf8"))
	answer.add_theme_font_size_override("normal_font_size", 22)
	answer.add_theme_stylebox_override("normal", box(Color("111e2d")))
	answer.text = "[안내]\n퓨즈를 찾기 전과 찾은 후에 같은 질문을 해보세요.\n아래 질문을 보내면 로컬 모델이 답변합니다."
	right.add_child(answer)
	question = LineEdit.new()
	question.text = "지금 무엇을 해야 해?"
	question.placeholder_text = "NPC에게 질문하기"
	question.custom_minimum_size.y = 48
	question.text_submitted.connect(func(_value): ask_npc())
	question.focus_entered.connect(func(): world.can_move = false)
	question.focus_exited.connect(func(): world.can_move = true)
	right.add_child(question)
	send_button = button("하린에게 물어보기", ask_npc)
	right.add_child(send_button)
	status = label("로컬 서버 연결 확인 중", 15, Color("92abc7"))
	right.add_child(status)
	metric_label = label("모델: %s  /  응답 시간 미측정" % config.model, 15, Color("92abc7"))
	right.add_child(metric_label)
	root.add_child(label("상태 반영 검증", 18, Color("cedbed")))
	var tools := HBoxContainer.new()
	tools.add_theme_constant_override("separation", 12)
	root.add_child(tools)
	tools.add_child(button("퓨즈 획득", func(): interact("fuse")))
	tools.add_child(button("전력 복구", func(): interact("generator")))
	tools.add_child(button("출구 이용", func(): interact("exit")))
	tools.add_child(button("처음부터 다시", reset_demo))
	tools.add_child(button("화면 저장 (F12)", capture_screen.bind("manual")))
	root.add_child(label("검증 버튼과 게임 속 상호작용은 같은 상태를 사용합니다. 대사 생성 중에도 이동할 수 있습니다.", 15, Color("7f9ab5")))
	update_state()

func box(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_content_margin_all(16)
	style.set_corner_radius_all(10)
	return style

func game_state() -> Dictionary:
	return {"fuse_collected": world.fuse_collected, "fuse_in_inventory": world.fuse_collected and not world.power_restored, "power_restored": world.power_restored, "escaped": world.finished}

func update_state() -> void:
	state_label.text = "퓨즈: %s    전력: %s    목표: %s" % ["획득" if world.fuse_collected else "미획득", "복구" if world.power_restored else "정지", "탈출 완료" if world.finished else "연구소 탈출"]

func interact(kind: String) -> void:
	if busy:
		status.text = "현재 상태의 답변을 받은 뒤 다시 상호작용하세요. 이동은 가능합니다."
		return
	match kind:
		"npc": ask_npc()
		"fuse":
			world.fuse_collected = true
			status.text = "퓨즈를 획득했습니다. 같은 질문으로 답변 변화를 확인하세요."
		"generator":
			if world.fuse_collected:
				world.power_restored = true
				status.text = "전력을 복구했습니다. 출구를 이용할 수 있습니다."
			else: status.text = "전력 장치를 켜려면 퓨즈가 필요합니다."
		"exit":
			if world.power_restored:
				world.finished = true
				status.text = "목표 달성. 다시 시작해 대화를 비교할 수 있습니다."
			else: status.text = "전력이 없어 출구를 열 수 없습니다."
	update_state()

func reset_demo() -> void:
	if busy: return
	world.reset_world()
	answer.text = "[안내]\n상태를 초기화했습니다. NPC에게 다시 질문해보세요."
	status.text = "같은 질문에 대한 상태별 대사를 확인하세요."
	update_state()

func check_ready(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
		status.text = "로컬 서버 연결 실패. START_DEMO.cmd로 실행하거나 실행 설명을 확인하세요."
		return
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	var found := false
	if parsed is Dictionary:
		for item in parsed.get("models", []):
			if item.get("name", "") == config.model: found = true
	status.text = "로컬 모델 준비 완료" if found else "서버 연결됨. %s 모델 준비가 필요합니다." % config.model

func ask_npc() -> void:
	if busy or question.text.strip_edges().is_empty(): return
	request_state = game_state().duplicate(true)
	var state_description := "퓨즈 미획득, 전력 정지"
	if request_state.power_restored: state_description = "퓨즈 사용 완료, 전력 복구 완료"
	elif request_state.fuse_in_inventory: state_description = "퓨즈 보유 중, 전력 정지"
	request_prompt = "현재 게임 상태: %s\n상태 설명: %s\n플레이어 질문: %s" % [JSON.stringify(request_state), state_description, question.text.strip_edges()]
	if config.get("thinking", false): request_prompt += "\n/no_think"
	busy = true
	request_sent = false
	buffer = PackedByteArray()
	generated = ""
	started_usec = Time.get_ticks_usec()
	first_usec = 0
	generation_frames = 0
	max_frame_ms = 0.0
	thinking_character_count = 0
	answer.text = "[로컬 모델 응답 대기 중]"
	status.text = "현재 상태를 로컬 모델에 전달하는 중"
	send_button.disabled = true
	question.editable = false
	question.release_focus()
	var error := client.connect_to_host(str(config.host), int(config.port))
	if error != OK: fail_request("연결 시작 실패: %s" % error)

func _process(delta: float) -> void:
	var frame_usec := Time.get_ticks_usec()
	var wall_gap_ms := (frame_usec - previous_frame_usec) / 1000.0 if previous_frame_usec > 0 else 0.0
	previous_frame_usec = frame_usec
	if busy:
		generation_frames += 1
		max_frame_ms = maxf(max_frame_ms, wall_gap_ms)
		poll_response()
	if evidence_mode and not busy:
		evidence_wait += delta
		if evidence_wait > 2.0:
			evidence_wait = 0.0
			run_evidence_step()

func poll_response() -> void:
	if Time.get_ticks_usec() - started_usec > 90000000:
		fail_request("90초 응답 시간초과")
		return
	var poll_error := client.poll()
	if poll_error != OK:
		fail_request("HTTP 처리 오류: %s" % poll_error)
		return
	var connection_status := client.get_status()
	if connection_status == HTTPClient.STATUS_CONNECTED and not request_sent:
		var payload := {"model": config.model, "system": config.system, "prompt": request_prompt, "stream": true, "keep_alive": "15m", "options": config.options}
		if config.get("thinking", false): payload["think"] = true
		var error := client.request(HTTPClient.METHOD_POST, "/api/generate", PackedStringArray(["Content-Type: application/json"]), JSON.stringify(payload))
		if error != OK: fail_request("요청 전송 실패: %s" % error)
		else: request_sent = true
	elif connection_status == HTTPClient.STATUS_BODY:
		if client.get_response_code() != 200:
			fail_request("로컬 서버 HTTP %s. 서버와 모델 설치를 확인하세요." % client.get_response_code())
			return
		buffer.append_array(client.read_response_body_chunk())
		consume_lines(false)
	elif request_sent and connection_status in [HTTPClient.STATUS_CONNECTED, HTTPClient.STATUS_DISCONNECTED]:
		consume_lines(true)
		if busy: fail_request("완료 표시 없이 연결이 끝났습니다.")
	elif connection_status in [HTTPClient.STATUS_CANT_CONNECT, HTTPClient.STATUS_CANT_RESOLVE, HTTPClient.STATUS_CONNECTION_ERROR, HTTPClient.STATUS_TLS_HANDSHAKE_ERROR]:
		fail_request("로컬 서버에 연결할 수 없습니다. 서버 실행 상태를 확인하세요.")

func consume_lines(flush: bool) -> void:
	while busy:
		var newline := buffer.find(10)
		if newline < 0:
			if flush and not buffer.is_empty():
				var remaining := buffer
				buffer = PackedByteArray()
				consume_event(remaining.get_string_from_utf8())
			return
		var line := buffer.slice(0, newline)
		buffer = buffer.slice(newline + 1)
		consume_event(line.get_string_from_utf8())

func consume_event(line: String) -> void:
	if line.strip_edges().is_empty(): return
	var event = JSON.parse_string(line)
	if not event is Dictionary:
		fail_request("응답 JSON 해석 실패")
		return
	if event.has("error"):
		fail_request(str(event.error))
		return
	var token := str(event.get("response", ""))
	thinking_character_count += str(event.get("thinking", "")).length()
	if not token.is_empty():
		if first_usec == 0: first_usec = Time.get_ticks_usec()
		generated += token
		answer.text = generated
		status.text = "로컬 모델이 대사를 생성하는 중"
	if event.get("done", false):
		if event.get("done_reason", "") == "length": fail_request("응답 길이 제한에 도달했습니다. 생성 설정과 대사를 확인하세요.")
		elif generated.strip_edges().is_empty(): fail_request("모델이 빈 대사를 반환했습니다.")
		else: finish_request(event)

func finish_request(metrics: Dictionary) -> void:
	var elapsed_ms := (Time.get_ticks_usec() - started_usec) / 1000.0
	var first_ms := (first_usec - started_usec) / 1000.0
	metrics.erase("context")
	var record := {"schema_version": 2, "run_id": OS.get_process_id(), "timestamp_utc": Time.get_datetime_string_from_system(true, true) + "Z", "source": "godot_live_stream", "prompt_mode": "instruction_dialogue_v1", "thinking_character_count": thinking_character_count, "model": config.model, "options": config.options, "state": request_state, "question": question.text, "response": generated, "first_text_ms": first_ms, "elapsed_ms": elapsed_ms, "frames_while_generating": generation_frames, "max_frame_ms": max_frame_ms, "metrics": metrics, "success": true, "quality_review": "not_automated"}
	if evidence_mode:
		var valid := generated.contains("퓨즈") and generated.contains("B")
		if request_state.fuse_in_inventory: valid = generated.contains("전력") and (generated.contains("장착") or generated.contains("설치") or generated.contains("복구"))
		if request_state.power_restored: valid = generated.contains("출구")
		valid = valid and not generated.contains("</think>") and not generated.begins_with("Okay")
		record["pilot_expected_word_check"] = valid
		if not valid: failures += 1
	append_record(record)
	metric_label.text = "%s  /  첫 대사 %.2f초  /  완료 %.2f초" % [config.model, first_ms / 1000.0, elapsed_ms / 1000.0]
	status.text = "로컬 생성 완료. 상태를 바꾸고 같은 질문을 해보세요."
	request_count += 1
	print("NPC_RESPONSE_OK ", JSON.stringify(record))
	end_request()

func fail_request(message: String) -> void:
	if not busy: return
	failures += 1
	answer.text = "[생성 실패]\n" + message
	status.text = "대체 대사를 생성하지 않았습니다. 오류는 기록했습니다."
	append_record({"schema_version": 2, "run_id": OS.get_process_id(), "timestamp_utc": Time.get_datetime_string_from_system(true, true) + "Z", "source": "godot_live_stream", "model": config.model, "state": request_state, "prompt": request_prompt, "partial_response": generated, "success": false, "error": message})
	push_warning(message)
	end_request()

func end_request() -> void:
	busy = false
	send_button.disabled = false
	question.editable = true
	client.close()

func append_record(record: Dictionary) -> void:
	var path := log_dir.path_join("npc_sessions.jsonl")
	var file := FileAccess.open(path, FileAccess.READ_WRITE if FileAccess.file_exists(path) else FileAccess.WRITE)
	if file:
		file.seek_end()
		file.store_line(JSON.stringify(record))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.physical_keycode == KEY_F12: capture_screen("manual")

func capture_screen(stem: String) -> void:
	await RenderingServer.frame_post_draw
	var path := log_dir.path_join(stem + ".png")
	get_viewport().get_texture().get_image().save_png(path)
	print("SCREENSHOT_SAVED ", path)

func run_evidence_step() -> void:
	if failures > 0:
		print("DEMO_EVIDENCE_FAILED")
		get_tree().quit(1)
		return
	match evidence_step:
		0: ask_npc()
		1:
			capture_screen("01_before_fuse")
		2:
			interact("fuse")
			ask_npc()
		3:
			capture_screen("02_after_fuse")
		4:
			interact("generator")
			ask_npc()
		5:
			capture_screen("03_after_power")
		6:
			interact("exit")
			capture_screen("04_ending")
		7:
			print("DEMO_EVIDENCE_PASS requests=", request_count, " escaped=", world.finished)
			get_tree().quit(0)
	evidence_step += 1

