extends Control

signal interacted(kind: String)

var player := Vector2(150, 350)
var npc := Vector2(365, 180)
var fuse := Vector2(220, 180)
var generator := Vector2(535, 180)
var exit_point := Vector2(580, 410)
var fuse_collected := false
var power_restored := false
var finished := false
var can_move := true
var font := SystemFont.new()

func _ready() -> void:
	font.font_names = PackedStringArray(["Malgun Gothic", "맑은 고딕"])
	custom_minimum_size = Vector2(680, 530)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	if can_move and not finished:
		var direction := Vector2.ZERO
		if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP): direction.y -= 1
		if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN): direction.y += 1
		if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT): direction.x -= 1
		if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT): direction.x += 1
		player += direction.normalized() * 175 * delta
		player = player.clamp(Vector2(58, 90), Vector2(625, 455))
	queue_redraw()

func _unhandled_key_input(event: InputEvent) -> void:
	if can_move and event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_E:
		for entry in [["npc", npc], ["fuse", fuse], ["generator", generator], ["exit", exit_point]]:
			if player.distance_to(entry[1]) < 72:
				interacted.emit(entry[0])
				break

func reset_world() -> void:
	player = Vector2(150, 350)
	fuse_collected = false
	power_restored = false
	finished = false

func text_at(pos: Vector2, value: String, color := Color("b8c5d8"), size := 18) -> void:
	draw_string(font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _draw() -> void:
	draw_style_box(panel(Color("111f30"), 16), Rect2(0, 0, 680, 530))
	text_at(Vector2(24, 36), "정전된 연구소", Color("f0f5ff"), 25)
	text_at(Vector2(24, 64), "퓨즈를 찾아 전력을 복구하고 탈출하세요", Color("97b3cc"), 16)
	draw_rect(Rect2(35, 80, 610, 395), Color("182b3c"))
	for x in range(35, 646, 40): draw_line(Vector2(x, 80), Vector2(x, 475), Color("203548"))
	for y in range(80, 476, 40): draw_line(Vector2(35, y), Vector2(645, y), Color("203548"))
	draw_rect(Rect2(35, 80, 610, 395), Color("425b70"), false, 3)
	text_at(Vector2(75, 122), "B구역", Color("647e93"), 18)
	text_at(Vector2(462, 122), "전력 제어실", Color("647e93"), 18)
	if not fuse_collected:
		draw_circle(fuse, 18, Color("f1c66d"))
		draw_rect(Rect2(fuse - Vector2(6, 13), Vector2(12, 26)), Color("523c20"))
		text_at(fuse + Vector2(-20, 42), "퓨즈", Color("f1c66d"))
	draw_style_box(panel(Color("2d6b6c"), 6), Rect2(npc - Vector2(18, 8), Vector2(36, 42)))
	draw_circle(npc - Vector2(0, 18), 15, Color("e3c0a3"))
	text_at(npc + Vector2(-38, 62), "정비사 하린", Color("8ce1d6"), 17)
	var machine_color := Color("6cbfa0") if power_restored else Color("6c5264")
	draw_style_box(panel(machine_color, 7), Rect2(generator - Vector2(28, 30), Vector2(56, 65)))
	draw_circle(generator, 10, Color("b5ffb8") if power_restored else Color("ee8995"))
	text_at(generator + Vector2(-35, 63), "전력 장치", machine_color, 17)
	draw_style_box(panel(Color("4d8269") if power_restored else Color("38495d"), 4), Rect2(exit_point - Vector2(24, 35), Vector2(48, 70)))
	text_at(exit_point + Vector2(-18, 62), "출구", Color("9bb6cb"), 17)
	draw_circle(player + Vector2(0, 15), 16, Color(0, 0, 0, 0.25))
	draw_style_box(panel(Color("7398f1"), 6), Rect2(player - Vector2(13, 2), Vector2(26, 32)))
	draw_circle(player - Vector2(0, 12), 12, Color("f4d8bd"))
	text_at(Vector2(24, 508), "WASD / 방향키 이동    E 상호작용", Color("9db5cc"), 17)
	if finished:
		draw_style_box(panel(Color(0.04, 0.12, 0.17, 0.94), 10), Rect2(115, 255, 450, 90))
		text_at(Vector2(202, 294), "연구소 탈출 성공", Color("a5ebc8"), 28)
		text_at(Vector2(196, 325), "다시 시작해 다른 질문도 해보세요", Color("c2d2dd"), 17)

func panel(color: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(radius)
	return style

