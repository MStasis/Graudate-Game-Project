@tool
class_name DemoWorld
extends Node2D
## 씬에서 옮긴 Player 위치가 시작과 재시작에 적용됩니다.
signal interacted(kind: String)
signal state_changed

@export_group("맵 설명")
@export var location_name: String = "정전된 연구소":
 set(value):
  location_name = value
  _sync_labels()
@export_multiline var objective_text: String = "퓨즈를 찾아 전력을 복구하고 탈출하세요":
 set(value):
  objective_text = value
  _sync_labels()
@export var room_rect := Rect2(35, 80, 610, 395):
 set(value):
  room_rect = value
  if is_node_ready(): _sync_room()
@export_group("게임 대상")
@export var player: DemoPlayer
@export var npc: DemoInteractable
@export var fuse: DemoInteractable
@export var generator: DemoInteractable
@export var exit_object: DemoInteractable

@export_group("AI 진행 안내")
@export_multiline var find_item_guidance: String = "{item_location}에서 {item_name}를 찾으세요."
@export_multiline var use_item_guidance: String = "{power_device}에 {item_name}를 장착해 전력을 복구하세요."
@export_multiline var leave_guidance: String = "{exit_name}로 이동해 탈출하세요."
@export_multiline var completed_guidance: String = "탈출을 완료했습니다. 성공을 축하하세요."

var fuse_collected := false
var power_restored := false
var finished := false
var _spawn_position := Vector2.ZERO
var _can_move := true
var can_move: bool:
 get: return _can_move
 set(value):
  _can_move = value
  if player: player.movement_enabled = value and not finished

func _ready() -> void:
 _sync_labels()
 _sync_room()
 if Engine.is_editor_hint(): return
 _spawn_position = player.position
 _sync_state()

func _sync_labels() -> void:
 var title := get_node_or_null("RoomTitle") as Label
 var goal := get_node_or_null("GoalText") as Label
 if title: title.text = location_name
 if goal: goal.text = objective_text

func _sync_room() -> void:
 var floor_panel := get_node_or_null("Floor") as Control
 if floor_panel:
  floor_panel.position = room_rect.position
  floor_panel.size = room_rect.size
 var walls := [
  ["North", Vector2(room_rect.get_center().x, room_rect.position.y), Vector2(room_rect.size.x, 6)],
  ["South", Vector2(room_rect.get_center().x, room_rect.end.y), Vector2(room_rect.size.x, 6)],
  ["West", Vector2(room_rect.position.x, room_rect.get_center().y), Vector2(6, room_rect.size.y)],
  ["East", Vector2(room_rect.end.x, room_rect.get_center().y), Vector2(6, room_rect.size.y)]]
 for entry in walls:
  var collider := get_node_or_null("Walls/" + entry[0]) as CollisionShape2D
  if collider:
   collider.position = entry[1]
   (collider.shape as RectangleShape2D).size = entry[2]

func _unhandled_input(event: InputEvent) -> void:
 if Engine.is_editor_hint() or not can_move or finished: return
 if not event.is_action_pressed("interact") or event.is_echo(): return
 var closest: DemoInteractable
 var distance := player.interaction_distance
 for target in [npc, fuse, generator, exit_object]:
  if not target or not target.visible: continue
  var target_distance := player.global_position.distance_to(target.global_position)
  if target_distance <= distance:
   closest = target
   distance = target_distance
 if closest:
  interacted.emit(closest.interaction_id)
  get_viewport().set_input_as_handled()

func apply_interaction(kind: String) -> String:
 var message := ""
 match kind:
  "fuse":
   fuse_collected = true
   message = "%s 획득. 같은 질문으로 답변 변화를 확인하세요." % fuse.display_name
  "generator":
   if fuse_collected:
    power_restored = true
    message = "%s 복구. %s를 이용할 수 있습니다." % [generator.display_name, exit_object.display_name]
   else: message = "%s에 %s가 필요합니다." % [generator.display_name, fuse.display_name]
  "exit":
   if power_restored:
    finished = true
    message = "목표 달성. 다시 시작해 대화를 비교할 수 있습니다."
   else: message = "%s를 먼저 복구해야 합니다." % generator.display_name
 _sync_state()
 state_changed.emit()
 return message

func _sync_state() -> void:
 if fuse: fuse.visible = not fuse_collected
 if generator: generator.set_active(power_restored)
 if exit_object: exit_object.set_active(power_restored)
 if player: player.movement_enabled = can_move and not finished
 var ending := get_node_or_null("Ending") as Control
 if ending: ending.visible = finished

func reset_world() -> void:
 fuse_collected = false
 power_restored = false
 finished = false
 player.position = _spawn_position
 player.velocity = Vector2.ZERO
 _can_move = true
 _sync_state()
 state_changed.emit()

func game_state() -> Dictionary:
 return {"fuse_collected": fuse_collected, "fuse_in_inventory": fuse_collected and not power_restored, "power_restored": power_restored, "escaped": finished}

func npc_context() -> Dictionary:
 return {"location": location_name, "objective": objective_text, "npc_name": npc.display_name, "npc_role": npc.description, "item_name": fuse.display_name, "item_location": fuse.location_hint, "power_device": generator.display_name, "exit_name": exit_object.display_name, "current_guidance": current_guidance(),
  "rules": ["fuse_collected=false일 때 %s에서 %s를 찾으라고 안내한다" % [fuse.location_hint, fuse.display_name], "fuse_in_inventory=true이고 power_restored=false이면 %s에 %s를 장착하라고 안내한다" % [generator.display_name, fuse.display_name], "power_restored=true이면 %s로 가라고 안내한다" % exit_object.display_name, "fuse_in_inventory=false이면 %s를 현재 보유하고 있다고 말하지 않는다" % fuse.display_name]}

func state_description() -> String:
 if finished: return "탈출 완료"
 if power_restored: return "%s는 이미 사용하여 현재 소지품에 없다. 전력 복구 완료" % fuse.display_name
 if fuse_collected: return "%s 보유 중, 전력 정지" % fuse.display_name
 return "%s 미획득, 전력 정지" % fuse.display_name

func current_guidance() -> String:
 var values := {"item_location": fuse.location_hint, "item_name": fuse.display_name, "power_device": generator.display_name, "exit_name": exit_object.display_name}
 if finished: return completed_guidance.format(values)
 if power_restored: return leave_guidance.format(values)
 if fuse_collected: return use_item_guidance.format(values)
 return find_item_guidance.format(values)
