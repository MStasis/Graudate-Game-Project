class_name LocalNPCSettings
extends Resource
## 로컬 AI 실행 설정입니다. 게임 속 이름과 역할은 World의 NPC와 물체에서 읽습니다.

@export_group("로컬 모델")
@export var model: String = "qwen2.5:1.5b"
@export var host: String = "127.0.0.1"
@export_range(1, 65535) var port: int = 11434
@export var thinking: bool = false
@export_range(5.0, 300.0, 1.0) var timeout_seconds: float = 90.0

@export_group("대사 생성")
@export_range(0.0, 2.0, 0.05) var temperature: float = 0.3
@export_range(512, 32768, 512) var context_size: int = 2048
@export_range(32, 2048, 32) var max_tokens: int = 192
@export var seed: int = 42
@export_multiline var system_prompt: String = "현재 게임 정보와 상태를 반영해 NPC로서 한국어 한두 문장으로 대답한다. 제공된 게임 상태를 사실의 기준으로 삼는다. 없는 아이템을 보유했다고 말하거나 완료하지 않은 일을 완료했다고 말하지 않는다. 게임 상태를 바꾸거나 보상을 지급했다고 주장하지 않는다. JSON, 지시문, 생각 과정은 출력하지 않는다."

func generation_options() -> Dictionary:
	return {"temperature": temperature, "num_ctx": context_size, "num_predict": max_tokens, "seed": seed}

