extends Control
## 화면 배치와 외형은 main.tscn, 맵은 scenes/World.tscn에서 편집합니다.
@onready var world: DemoWorld = %World
@onready var ai: LocalAIClient = $AI
@onready var answer: RichTextLabel = %Answer
@onready var question: LineEdit = %Question
@onready var status: Label = %Status
@onready var state_label: Label = %StateSummary
@onready var metric_label: Label = %Metrics
@onready var send_button: Button = %SendButton
@onready var npc_name: Label = %NPCName
var log_dir := ""
var evidence_mode := false
var evidence_step := 0
var evidence_wait := 0.0
var request_count := 0
var failures := 0
var _intro_text := ""
var busy: bool:
 get: return ai.busy
 set(value): ai.busy = value

func _ready() -> void:
 evidence_mode = "--demo-evidence" in OS.get_cmdline_user_args()
 log_dir = ProjectSettings.globalize_path("res://../evidence" + ("/scene_refactor" if evidence_mode else "")).simplify_path()
 DirAccess.make_dir_recursive_absolute(log_dir)
 ai.log_dir = log_dir
 _intro_text = answer.text
 world.interacted.connect(interact)
 world.state_changed.connect(update_state)
 question.text_submitted.connect(func(_value): ask_npc())
 question.focus_entered.connect(func(): world.can_move = false)
 question.focus_exited.connect(func(): world.can_move = true)
 send_button.pressed.connect(ask_npc)
 %CollectButton.pressed.connect(interact.bind("fuse"))
 %PowerButton.pressed.connect(interact.bind("generator"))
 %ExitButton.pressed.connect(interact.bind("exit"))
 %RestartButton.pressed.connect(reset_demo)
 %CaptureButton.pressed.connect(capture_screen.bind("manual"))
 ai.started.connect(_generation_started)
 ai.partial_text.connect(func(text): answer.text = text)
 ai.completed.connect(_generation_completed)
 ai.failed.connect(_generation_failed)
 ai.readiness.connect(func(message): status.text = message)
 npc_name.text = world.npc.display_name
 metric_label.text = "%s / 응답 시간 미측정" % ai.settings.model
 update_state()
 ai.check_connection()

func game_state() -> Dictionary:
 var snapshot := world.game_state()
 snapshot["scene_context"] = world.npc_context()
 return snapshot

func update_state() -> void:
 state_label.text = "%s: %s    전력: %s    진행: %s" % [world.fuse.display_name, "획득" if world.fuse_collected else "미획득", "복구" if world.power_restored else "정지", "완료" if world.finished else "진행 중"]

func interact(kind: String) -> void:
 if busy:
  status.text = "현재 답변이 끝난 뒤 상태를 변경하세요. 이동은 가능합니다."
  return
 if kind == "npc":
  ask_npc()
  return
 status.text = world.apply_interaction(kind)

func reset_demo() -> void:
 if busy: return
 world.reset_world()
 answer.text = _intro_text
 status.text = "씬에 저장한 시작 위치와 초기 상태로 돌아왔습니다."

func ask_npc() -> void:
 if busy or question.text.strip_edges().is_empty(): return
 var snapshot := game_state()
 var context := world.npc_context()
 var system_text := "너는 %s이다. %s 장소: %s.\n%s\n진행 방법을 물으면 게임이 제공한 현재 진행 안내를 설명한다. 다른 단계의 행동이나 장소를 새로 만들지 않는다." % [world.npc.display_name, world.npc.description, world.location_name, ai.settings.system_prompt]
 var prompt := "현재 게임 상태: %s\n게임이 확인한 사실: %s\n현재 진행 안내: %s\n플레이어 질문: %s" % [JSON.stringify(world.game_state()), world.state_description(), world.current_guidance(), question.text.strip_edges()]
 if ai.settings.thinking: prompt += "\n/no_think"
 ai.generate(system_text, prompt, snapshot, question.text.strip_edges())

func _generation_started() -> void:
 answer.text = "[로컬 모델 응답 대기 중]"
 status.text = "현재 게임 상태와 씬의 NPC 정보를 전달하는 중"
 send_button.disabled = true
 question.editable = false
 question.release_focus()

func _generation_completed(record: Dictionary) -> void:
 send_button.disabled = false
 question.editable = true
 answer.text = record.response
 metric_label.text = "%s / 첫 대사 %.2f초 / 완료 %.2f초" % [ai.settings.model, record.first_text_ms / 1000.0, record.elapsed_ms / 1000.0]
 status.text = "로컬 생성 완료. 상태를 바꾸고 같은 질문을 해보세요."
 request_count += 1
 if evidence_mode:
  var valid: bool = record.response.contains(world.fuse.display_name)
  if world.fuse_collected and not world.power_restored: valid = record.response.contains(world.generator.display_name) and not record.response.contains(world.exit_object.display_name)
  if world.power_restored: valid = record.response.contains(world.exit_object.display_name) or record.response.contains("탈출")
  if not valid or record.response.contains("</think>"): failures += 1
 print("NPC_RESPONSE_OK ", JSON.stringify(record))

func _generation_failed(message: String) -> void:
 failures += 1
 send_button.disabled = false
 question.editable = true
 answer.text = "[생성 실패]\n" + message
 status.text = "오류를 기록했습니다. 대체 대사를 사용하지 않았습니다."
 push_warning(message)

func _process(delta: float) -> void:
 if evidence_mode and not busy:
  evidence_wait += delta
  if evidence_wait > 2.0:
   evidence_wait = 0.0
   _run_evidence_step()

func _unhandled_key_input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed and event.physical_keycode == KEY_F12: capture_screen("manual")

func capture_screen(stem: String) -> void:
 await RenderingServer.frame_post_draw
 var path := log_dir.path_join(stem + ".png")
 get_viewport().get_texture().get_image().save_png(path)
 print("SCREENSHOT_SAVED ", path)

func _run_evidence_step() -> void:
 if failures > 0:
  print("DEMO_EVIDENCE_FAILED")
  get_tree().quit(1)
  return
 match evidence_step:
  0: ask_npc()
  1: capture_screen("01_before_fuse")
  2:
   interact("fuse")
   ask_npc()
  3: capture_screen("02_after_fuse")
  4:
   interact("generator")
   ask_npc()
  5: capture_screen("03_after_power")
  6:
   interact("exit")
   capture_screen("04_ending")
  7:
   print("DEMO_EVIDENCE_PASS requests=", request_count, " escaped=", world.finished)
   get_tree().quit(0)
 evidence_step += 1
