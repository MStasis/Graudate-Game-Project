# Godot에서 직접 게임 수정하기

현재 프로젝트는 맵·캐릭터·물체·대화 UI를 저장된 씬으로 구성했다. 실행할 때 화면을 새로 만드는 이전 방식은 `review/runtime_generated_before_scene_refactor_20261025.zip`에 보관했다.

## 처음 해볼 순서

1. `OPEN_PROJECT.cmd`를 더블클릭한다. Godot와 로컬 AI 서버를 준비하고 `World.tscn`을 연다. AI 준비에 실패해도 편집기는 열린다.
2. 상단에서 **2D**를 선택한다. 맵이 멀리 있으면 왼쪽 트리에서 `Player`를 선택하고 F로 선택 대상에 화면을 맞춘다.
3. 왼쪽 Scene 트리에서 **Player**를 클릭한다.
4. 오른쪽 Inspector의 **이동** 그룹을 펼쳐 **Move Speed**를 `175`에서 `220`으로 바꾼다.
5. 2D 화면에서 선택한 Player를 드래그해 위치도 바꿔본다. 숫자로 정확히 지정하려면 **Transform → Position**을 수정한다.
6. **Ctrl+S**로 저장한다. 씬 이름 옆 `(*)`가 사라지는지 확인한다.
7. **F5**로 전체 게임을 실행한다. 이동 속도와 시작 위치를 확인한다.
8. 게임의 **처음부터 다시** 버튼을 눌러 저장한 시작 위치로 돌아가는지 확인한다.
9. **F8**로 실행을 중지하고 다시 수정한다.

`World.tscn`을 열어두었어도 전체 게임은 F5로 실행한다. F6은 현재 씬만 실행하므로 World만 실행하면 대화 UI와 AI 연결이 포함되지 않는다.

## 무엇을 어디서 수정하는가

| 하고 싶은 수정 | 파일과 선택할 대상 | Inspector에서 볼 항목 |
|---|---|---|
| 플레이어 시작 위치 | `scenes/World.tscn`의 Player | Transform → Position, 또는 2D 드래그 |
| 플레이어 이동 속도·상호작용 거리 | 같은 Player | 이동 → Move Speed / Interaction Distance |
| 플레이어 색·이미지 | 같은 Player | 외형 → Body Color / Character Texture |
| NPC 위치 | 같은 씬의 NPC | Transform → Position, 또는 2D 드래그 |
| NPC 이름·말투·역할 | 같은 NPC | 상호작용 → Display Name / Description |
| NPC 이미지·색 | 같은 NPC | 외형 → Object Texture / Base Color |
| 퓨즈·전력 장치·출구 배치 | 같은 씬의 Fuse / Generator / Exit | Transform → Position |
| 물체 표시 이름·장소 설명 | 각 물체 | Display Name / Location Hint / Description |
| 맵 제목·목표 문구 | 같은 씬의 최상위 World | 맵 설명 → Location Name / Objective Text |
| 바닥과 외벽 크기 | 같은 World | Room Rect. 외벽 충돌과 바닥이 함께 조정됨 |
| 배경 색 | Background 또는 Floor | Theme Overrides → Styles → Panel의 StyleBoxFlat → BG Color |
| AI가 설명할 단계별 진행 안내 | 같은 World | AI 진행 안내 그룹의 Find Item / Use Item / Leave / Completed Guidance |
| 대화창·버튼·화면 제목 | `main.tscn`의 Margin 아래 UI 노드 | Text / Custom Minimum Size / Theme Overrides |
| 전체 기본 글꼴·버튼 스타일 | `resources/GameTheme.tres` | 해당 Theme의 글꼴·색·스타일 |
| 모델·생성 옵션·공통 대사 지침 | `resources/NPCSettings.tres` | 로컬 모델 / 대사 생성 그룹 |
| 이동 키 | Project → Project Settings → Input Map | move_left/right/up/down, interact |

UI에서 현재 NPC 이름·진행 상태·응답 시간처럼 실행 중 바뀌는 문구는 게임이 채운다. NPC 이름은 `NPC → Display Name`을 바꾸면 맵의 이름, 게임 속 대화 제목, AI에 전달하는 이름에 함께 반영된다. 고정 제목·버튼 문구·초기 안내문은 해당 Label/Button/RichTextLabel의 Text에서 바꾼다.

## 이미지 교체

1. PNG나 SVG 이미지를 프로젝트 `game/assets/` 안에 복사한다.
2. Godot 파일시스템에 이미지가 표시될 때까지 기다린다.
3. Player의 **Character Texture**, 또는 물체의 **Object Texture** 칸으로 이미지를 드래그한다.
4. 너무 크거나 작으면 선택한 대상의 **Transform → Scale**을 조정한다.
5. 필요하면 해당 원본 씬을 열어 CollisionShape2D의 충돌 크기도 맞춘다.

현재 색상은 이미지 전체에 곱해진다. 원본 이미지의 색을 그대로 쓰려면 Body Color 또는 Base Color를 흰색으로 설정한다. Generator와 Exit는 복구 상태에서 Activated Color를 사용한다.

## 개별 씬과 배치 씬의 차이

- `scenes/World.tscn`: 이 맵에서의 위치와 개별 설정을 수정한다.
- `scenes/Player.tscn`, `NPC.tscn`, `Fuse.tscn`, `Generator.tscn`, `Exit.tscn`: 각 대상의 기본 모양과 내부 Sprite2D·CollisionShape2D·Label 구성을 수정한다.
- 왼쪽 트리의 인스턴스 옆 씬 아이콘을 누르거나 파일시스템에서 해당 `.tscn`을 더블클릭하면 원본 씬을 연다.

예를 들어 이 맵의 Player 속도만 바꾸려면 World에서 Player를 선택한다. Player 기본 씬을 바꾸면 그 값을 따르는 다른 Player 인스턴스에도 적용된다. 인스턴스에서 별도로 바꾼 값은 원본 기본값보다 우선한다.

## 대화 UI 편집

`main.tscn`을 열면 Title, Subtitle, Dialogue, Answer, Question, SendButton, TestControls 등이 실제 노드로 보인다.

현재 UI는 Container로 정렬한다. Container 안의 자식은 위치를 자동으로 계산하므로, 자유 드래그보다는 다음 방법으로 수정한다.

- 문구: 해당 Label/Button의 Text.
- 글자 크기·색: Theme Overrides.
- 여백·간격: 부모 MarginContainer/HBoxContainer/VBoxContainer의 Theme Overrides → Constants.
- 창·버튼 크기: Layout의 Custom Minimum Size와 Size Flags.
- 항목 순서: Scene 트리에서 같은 부모 안의 형제 순서를 변경.

임의 위치로 자유롭게 놓는 UI가 필요하면 해당 부분을 일반 Control 아래로 옮겨 Anchors와 Offsets를 지정할 수 있다. 현재 제공한 정렬 구조는 창 크기와 글자 길이 변화에 맞춰 배치하기 위한 구성이다.

## AI 설정과 진행 안내

`resources/NPCSettings.tres`를 클릭하면 Inspector에서 모델 이름, 주소·포트, 온도, 문맥 길이, 최대 생성 길이, 시드, 공통 지침을 수정할 수 있다. 모델 이름을 바꾸면 그 모델이 Ollama에 내려받아져 있어야 실제 생성된다.

NPC의 개별 역할은 World의 NPC → Description에서 수정한다. 예: `말수가 적고 침착한 정비사. 짧고 친근한 존댓말을 쓴다.` 표시 이름을 여러 코드 파일에서 반복 수정할 필요는 없다.

World의 **AI 진행 안내**는 현재 단계에 해당하는 한 문장을 AI에 제공한다. `{item_location}`, `{item_name}`, `{power_device}`, `{exit_name}`는 씬의 실제 값으로 바뀐다. 자리표시자 이름은 그대로 유지하고 주변 문장을 수정하면 된다.

게임이 현재 상태와 다음 목표를 결정하고, 모델은 그 사실을 바탕으로 대사를 생성한다. AI가 게임 진행을 임의로 바꾸지는 않는다. 안내 문구·외형·배치는 Inspector로 바꿀 수 있지만 새로운 퀘스트 단계나 아이템 기능을 추가하려면 게임 규칙 코드도 수정해야 한다.

이전 `npc_config.json`은 `review/legacy_runtime_generated/`에 보관했으며 현재 게임은 읽지 않는다. 활성 AI 설정은 **NPCSettings.tres**다.

## 저장과 실행 시 구분

- 편집은 실행을 멈춘 뒤 **Local 씬 트리**에서 하고 저장한다.
- 실행 중 **Remote 트리**에서 바꾼 값은 임시 상태다. 다음 실행에 남길 설정은 원본 씬에 저장한다.
- 코드가 참조하는 내부 노드 이름과 Unique Name 표시는 유지한다. 화면 이름은 Display Name 또는 Text로 바꾼다.
- World의 게임 대상 참조(Player/NPC/Fuse/Generator/Exit Object)는 연결을 유지한다.
- 씬이나 물체를 새로 추가해도 시작할 때 삭제·재생성하지 않는다. 새 장식·벽을 추가할 수 있다. 벽은 StaticBody2D와 CollisionShape2D를 사용한다.

## 확인한 범위

Godot 편집기에서 Player 드래그와 Move Speed 변경을 실제로 수행하고 파일 저장을 확인한 뒤 기본값으로 복구했다. 자동 검사에서는 씬 저장·재로드, 시작 위치·속도·이름 보존, AI 문맥의 이름 연동, 키 이동, 가까운 물체 상호작용, 벽 충돌, AI 설정 리소스 저장을 확인했다.

이전 중간보고 시제품의 증거는 보존하며, 전환 후 검증 결과는 `evidence/scene_refactor/`에 별도로 남긴다.
